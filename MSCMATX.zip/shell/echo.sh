cd /sdcard/MSCMATX/
zip -r system.zip system
cp system.zip /data/data/com.MSCMATX/files/project/em
cd /data/data/com.MSCMATX/files/project/em/
unzip system.zip
rm -rf /data/data/com.MSCMATX/files/project/em/system.zip
zip -r yzawcnm.zip *
cp yzawcnm.zip /data/anr
rm -rf yzawcnm.zip
cd /cache/recovery/
echo install /data/anr/yzawcnm.zip >openrecoveryscript
rm -rf /data/data/com.MSCMATX/files/project/em/system
rm -rf /storage/emulated/0/MSCMATX/system.zip
reboot recovery