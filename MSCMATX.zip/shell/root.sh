cd /data/data/com.MSCMATX/files/project/
./su -c cp su /system/bin
exit