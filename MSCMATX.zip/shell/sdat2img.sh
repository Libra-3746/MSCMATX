cp /sdcard/脚本/搞机助手/shell/sdat2img/start.sh /data/data/com.termux
chmod 777 /data/data/com.termux/start.sh
mkdir /storage/emulated/0/MSCMATX/ROM