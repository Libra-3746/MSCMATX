sed -i 's@^\(deb.*stable main\)$@#\1\ndeb https://mirrors.tuna.tsinghua.edu.cn/termux/termux-packages-24 stable main@' $PREFIX/etc/apt/sources.list
sed -i 's@^\(deb.*games stable\)$@#\1\ndeb https://mirrors.tuna.tsinghua.edu.cn/termux/game-packages-24 games stable@' $PREFIX/etc/apt/sources.list.d/game.list
sed -i 's@^\(deb.*science stable\)$@#\1\ndeb https://mirrors.tuna.tsinghua.edu.cn/termux/science-packages-24 science stable@' $PREFIX/etc/apt/sources.list.d/science.list
apt update && apt upgrade -y
pkg install python -y
pkg install wget -y
pkg install git -y
git clone https://github.com/xpirt/sdat2img
cd sdat2img
chmod 777 *
cp /storage/emulated/0/MSCMATX/ROM/system.transfer.list /data/data/com.termux/sdat2img
cp /storage/emulated/0/MSCMATX/ROM/system.new.dat /data/data/com.termux/sdat2img
./sdat2img.py system.transfer.list system.new.dat system.img
rm -rf /data/data/com.termux/start.sh
cp /data/data/com.termux/sdat2img/system.img /storage/emulated/0/MSCMATX/ROM
su -c pkill com.termux