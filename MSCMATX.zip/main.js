"ui";

var color = "#009688";

ui.layout(
    <drawer id="drawer">
   shell("chmod 777 /data/data/com.MSCMATX/files/project/shell",true)
        <vertical>
            <appbar>
                <toolbar id="toolbar" title="MSCMATX 1.0.2"/>
                <tabs id="tabs"/>
            </appbar>
            <viewpager id="viewpager">            
                <frame>                
                
                     ui.layout(
                <vertical padding="16">
                      
                         <button id="s1" text="获取ROOT" w="*"/>
                         <button id="s2" text="刷入BOOT" w="*"/>
                         <button id="s3" text="获取WIFI密码" w="*"/>
                         <button id="s4" text="修改电量" w="*"/>
                         <button id="s6" text="安装字体/修改开机动画" w="*"/>
                         <button id="s7" text="Termux欢迎修改（期待1.0.2）" w="*"/>
                         <button id="s8" text="开启应用小窗" w="*"/>
                         <button id="s19" text="防止覆盖TWRP/recovery（期待1.0.2）" w="*"/>
                         <button id="s20" text="刷入镜像到recovery分区（期待1.0.2）" w="*"/>
                        <text text="                     YZA女装！！！(已开源)" textColor="red" textSize="16sp"/>
                
                    </vertical>
                
                </frame>
                <frame>
                     ui.layout(
                <vertical padding="16">
                      
                         <button id="s11" text="刷入REC" w="*"/>
                         <button id="s21" text="一键转换为Magisk（期待1.0.2）" w="*"/>
                         <button id="s22" text="禁用AVB2.0的启动校验/DM校验（期待1.0.2）" w="*"/>
                         <button id="s23" text="禁用AVB2.0的启动校验/D" w="*"/>
                         <button id="s23" text="恢复电量" w="*"/>
                        <text text="                     YZA女装！！！(已开源,1.0.2再加一点功能)" textColor="red" textSize="16sp"/>
                
                    </vertical>
                
                </frame>
                <frame>
                                     ui.layout(
                <vertical padding="16">
                      
                         <button id="17" text="准备环境（服务器）" w="*"/>
                         <button id="18" text="开服务器（服务器）" w="*"/>
                
                    </vertical>
                
                </frame>
            </viewpager>
        </vertical>
        <vertical layout_gravity="left" bg="#ffffff" w="280">
            <img w="280" h="200" scaleType="fitXY" src="http://images.shejidaren.com/wp-content/uploads/2014/10/023746fki.jpg"/>
            <list id="menu">
                <horizontal bg="?selectableItemBackground" w="*">
                    <img w="50" h="50" padding="16" src="{{this.icon}}" tint="{{color}}"/>
                    <text textColor="black" textSize="15sp" text="{{this.title}}" layout_gravity="center"/>
                </horizontal>
            </list>
        </vertical>
    </drawer>
);


//创建选项菜单(右上角)
ui.emitter.on("create_options_menu", menu=>{
    menu.add("设置");
    menu.add("重启REC");
    menu.add("重启9008");
    menu.add("重启");
    menu.add("重启Fastboot");
    menu.add("黄♂");
    menu.add("关于");
});
//监听选项菜单点击
ui.emitter.on("options_item_selected", (e, item)=>{
    switch(item.getTitle()){
        case "设置":
            toast("还没有设置");
            break;
        case "关于":
            alert("关于", "作者 Libra 第一个正式版1.0.0！谢谢大家使用，1.0.2会更新的更多内容，酷安 Linuxboot");
            break;
        case "重启":
            shell("reboot",true)
            break;
        case "重启REC":
            shell("reboot recovery",true)
            break;
        case "重启9008":
            shell("reboot edl",true)
            break;
        case "重启Fastboot":
            shell("reboot bootloader",true)
            break;
        case "重启sideload":
            shell("reboot sideload",true)
            break;
        case "软重启":
            shell("su -c killall -9 zygote || setprop ctl.restart zygote",true)
            break;
        case "重启至安全模式":
            shell("su -c setprop persist.sys.safemode 1 &#38;&#38; reboot",true)
            break;
        case "强制关机":
            shell("reboot -p",true)
            break;
        case "重启SystemUI":
            shell("pkill -f com.android.systemui",true)
            break;
        case "黄♂":
            alert("YZAWC", "每日一机");
            break;
    }
    e.consumed = true;
});
activity.setSupportActionBar(ui.toolbar);

//设置滑动页面的标题
ui.viewpager.setTitles(["搞机区", "Termux区", "分享美化包区"]);
//让滑动页面和标签栏联动
ui.tabs.setupWithViewPager(ui.viewpager);

//让工具栏左上角可以打开侧拉菜单
ui.toolbar.setupWithDrawer(ui.drawer);

ui.menu.setDataSource([
  {
      title: "作者Libra",
      icon: "@drawable/ic_android_black_48dp"
  },
  {
      title: "MSCMATX工具箱 1.0.0",
      icon: "@drawable/ic_settings_black_48dp"
  },
  {
      title: "欢迎反馈",
      icon: "@drawable/ic_favorite_black_48dp"
  },
  {
      title: "退出",
      icon: "@drawable/ic_exit_to_app_black_48dp"
  }
]);

ui.menu.on("item_click", item => {
    switch(item.title){
        case "退出":
            ui.finish();
            break;
    }
})

ui.s1.on("click", ()=>{
    
   shell("chmod 777 /data/data/com.MSCMATX/files/project/shell",true)
   shell("mkdir /sdcard/MSCMATX",true)
   shell("./data/data/com.MSCMATX/files/project/shell/su -c cp /data/data/com.MSCMATX/files/project/su /system/bin",true)
            toast("成功");
});

ui.s2.on("click", ()=>{
    
   shell("chmod 777 /data/data/com.MSCMATX/files/project/shell",true)
   shell("mkdir /sdcard/MSCMATX",true)
   shell("su -c dd if=/sdcard/MSCMATX/*.img of=/dev/boot",true)
            toast("成功");
});


ui.s4.on("click", ()=>{
    
   shell("chmod 777 /data/data/com.MSCMATX/files/project/shell",true)
   shell("mkdir /sdcard/MSCMATX",true)
   shell("su -c dumpsys battery set level 100",true)
            toast("成功");
});




ui.s6.on("click", ()=>{
   shell("su -c ./data/data/com.MSCMATX/files/project/shell/echo.sh",true)
   shell("chmod 777 /data/data/com.MSCMATX/files/project/shell/*",true)   
   shell("mkdir /sdcard/MSCMATX/fonts",true)
   shell("mkdir /sdcard/MSCMATX/media",true)
   shell("mkdir /data/anr",true)
   alert("HELP", "media是放开机动画，fonts是字体，去看/sdcard/MSCMATX/system");
            toast("成功");
});


ui.s7.on("click", ()=>{
    
   shell("chmod 777 /data/data/com.MSCMATX/files/project/shell",true)
   shell("mkdir /sdcard/MSCMATX",true)
   shell("su -c settings put global enable_freeform_support 1",true)
            toast("成功");
});


ui.s8.on("click", ()=>{
    
   shell("chmod 777 /data/data/com.MSCMATX/files/project/shell",true)
   shell("mkdir /sdcard/MSCMATX",true)
   shell("su -c dumpsys battery set level 100",true)
            toast("成功");
});


ui.s11.on("click", ()=>{
   shell("mkdir /sdcard/MSCMATX",true)
   
   shell("chmod 777 /data/data/com.MSCMATX/files/project/shell",true)
   shell("su -c dd if=/sdcard/MSCMATX/*.rec.img of=/dev/recovery",true)
            toast("成功");
});

ui.s23.on("click", ()=>{
    
   shell("chmod 777 /data/data/com.MSCMATX/files/project/shell",true)
   shell("mkdir /sdcard/MSCMATX",true)
   shell("su -c dumpsys battery reset",true)
            toast("成功");
});
